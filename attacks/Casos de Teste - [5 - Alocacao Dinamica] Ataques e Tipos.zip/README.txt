Arquivo zip gerado em: 05/01/2022 20:11:03 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [5 - Alocação Dinâmica] Ataques e Tipos